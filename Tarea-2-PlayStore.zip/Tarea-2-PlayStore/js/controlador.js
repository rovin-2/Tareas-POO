var aplicaciones = [
   //{
   //    nombreAplicacion: 'App 1',
   //    urlImagen: 'img/icon1.png.webp',
   //    desarrollador: 'Facebook',
   //    calificacion: 3
   //},
//
   // {
   //     nombreAplicacion: 'App 2',
   //     urlImagen: 'img/icon2.png.webp',
   //     desarrollador: 'Google',
   //     calificacion: 4
   // },
//
   // {
   //     nombreAplicacion: 'App 3',
   //     urlImagen: 'img/icon3.png.webp',
   //     desarrollador: 'Amazon',
   //     calificacion: 5
   // },
//
   // {
   //     nombreAplicacion: 'App 4',
   //     urlImagen: 'img/icon4.png.webp',
   //     desarrollador: 'Windows',
   //     calificacion: 4
   // },
//
   // {
   //     nombreAplicacion: 'App 5',
   //     urlImagen: 'img/icon5.png.webp',
   //     desarrollador: 'Apple',
   //     calificacion: 3
   // },
//
   // {
   //     nombreAplicacion: 'App 6',
   //     urlImagen: 'img/icon6.png.webp',
   //     desarrollador: 'Mac',
   //     calificacion: 2
   // },
//
   // {
   //     nombreAplicacion: 'App 7',
   //     urlImagen: 'img/icon7.png.webp',
   //     desarrollador: 'Android',
   //     calificacion: 2
   // }
 ];
 var localStorage = window.localStorage;
 var indiceAppSeleccionada = null

 console.log('APLICACIONES: ', localStorage.getItem('aplicaciones'));
 if(localStorage.getItem('aplicaciones') == null ){
     localStorage.setItem('aplicaciones', JSON.stringify(aplicaciones)); //de JSON a cadenada
   //console.log(JSON.parse(localStorage.getItem('aplicaciones'))); //de cadena a JSON
 }else{
     aplicaciones = JSON.parse(localStorage.getItem('aplicaciones'));
 }

 for (let i=1; i<=30; i++){
    document.getElementById('lista-imagenes').innerHTML +=
    `<option value="img/icon${i}.png.webp">Imagen ${i}</option>`;
 }


function generarAplicaciones() {
    document.getElementById('aplicaciones').innerHTML = '';
    aplicaciones.forEach(function(app, i) {
        let estrellas = '';

        for (let i=0; i< app.calificacion; i++){
            estrellas += '<i class="fas fa-star"></i>';
        }
        for (let i=0; i< (5-app.calificacion); i++){
            estrellas += '<i class="far fa-star"></i>';
        }
    
        document.getElementById('aplicaciones').innerHTML +=
        `<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2">
         <div class="card">
            <img src="${app.urlImagen}" class="card-img-top app-img" onclick="editarApp(${i})">
               <div class="card-body">
                <h5 class="card-title">${app.nombreAplicacion}</h5>
                <p class="card-text">Desarrollador: ${app.desarrollador}</p>
                <div>
                   ${estrellas} 
                   <button class="btn btn-outline-danger btn-sm" style="float:right" onclick="eliminar(${i})"><i class="fas fa-trash-alt"></i></button>
                </div>
               </div>
           </div>
       </div>`;

    });
}

generarAplicaciones();

function validarCampoVacio(id) {
    let campo = document.getElementById(id);
    if (campo.value == ''){
        campo.classList.remove('input-success');
        campo.classList.add('input-error');
    }else{
        campo.classList.remove('input-error');
        campo.classList.add('input-success');
    }

}

function guardar() {
   const app = {
        nombreAplicacion: document.getElementById('nombre-app').value,
        urlImagen: document.getElementById('lista-imagenes').value,
        desarrollador: document.getElementById('desarrollador').value,
        calificacion: document.getElementById('calificacion').value
        
    };
    console.log(app);
    aplicaciones.push(app);
    localStorage.setItem('aplicaciones', JSON.stringify(aplicaciones));
    console.log(aplicaciones);
    generarAplicaciones();
    $('#modalNuevaApp').modal('hide')

}

function eliminar(indice) {
   console.log('Eliminar aplicacion con el indice', indice);
   aplicaciones.splice(indice, 1); //Eliminar de un arreglo
   generarAplicaciones();
   localStorage.setItem('aplicaciones', JSON.stringify(aplicaciones));
}

function editarApp(indice) {
   document.getElementById('aplicaciones').innerHTML = '';
   aplicaciones.forEach(function(app, i) {
       let estrellas = '';

       for (let i=0; i< app.calificacion; i++){
           estrellas += '<i class="fas fa-star"></i>';
       }
       for (let i=0; i< (5-app.calificacion); i++){
           estrellas += '<i class="far fa-star"></i>';
       }
   
       document.getElementById('aplicaciones').innerHTML +=
       `<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2">
        <div class="card">
           <img src="${app.urlImagen}" class="card-img-top app-img" onclick="editarApp(${i})">
              <div class="card-body">
               <h5 class="card-title">${app.nombreAplicacion}</h5>
               <p class="card-text">Desarrollador: ${app.desarrollador}</p>
               <div>
                  ${estrellas} 
                  <button class="btn btn-outline-danger btn-sm" style="float:right" onclick="eliminar(${i})"><i class="fas fa-trash-alt"></i></button>
               </div>
              </div>
          </div>
      </div>`;

   });


  console.log('Editar', indice);
  // indiceAppSeleccionada = indice;
  $('#modalNuevaApp').modal('show');
  // let app = aplicaciones[indice];
  //  document.getElementById('nombre-app').value = app.nombreAplicacion;
  //  document.getElementById('desarrollador').value =  app.desarrollador;
  //  document.getElementById('calificacion').value =  app.calificacion;
  //  document.getElementById('lista-imagenes').value =  app.urlImagen;
  //
  // document.getElementById('btn-guardar').style.display = 'none';  
  // document.getElementById('btn-actualizar').style.display = 'block';
}
 function actualizar() {
  console.log('Se actualiza el app con indice', indiceAppSeleccionada);
  aplicaciones[indiceAppSeleccionada] = {
   nombreAplicacion: document.getElementById('nombre-app').value,
   urlImagen: document.getElementById('lista-imagenes').value,
   desarrollador: document.getElementById('desarrollador').value,
   calificacion: document.getElementById('calificacion').value
  };
  localStorage.setItem('aplicaciones', JSON.stringify(aplicaciones));
  generarAplicaciones();
  $('#modalNuevaApp').modal('hide');
 }

 function nuevaApp() {
   indiceAppSeleccionada = null;
   document.getElementById('nombre-app').value =  null;
    document.getElementById('desarrollador').value = null;
    document.getElementById('calificacion').value = null;
    document.getElementById('lista-imagenes').value = null;
    
   document.getElementById('btn-guardar').style.display = 'block';  
   document.getElementById('btn-actualizar').style.display = 'none';
 }